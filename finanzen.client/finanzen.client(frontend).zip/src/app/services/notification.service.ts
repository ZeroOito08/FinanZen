import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private toastr: ToastrService) { }

  showSuccess(message: string, title: string = 'Sucesso'): void {
    this.toastr.success(message, title);
  }

  showError(message: string, title: string = 'Erro'): void {
    this.toastr.error(message, title);
  }

  showWarning(message: string, title: string = 'Aviso'): void {
    this.toastr.warning(message, title);
  }
}